export class Appointment
{

    userId:number;
    userName:string;
    email:string;
    contactNo:string;
    
}