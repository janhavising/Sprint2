export class Test
{

    testId : string;;
    testName :string;
    
}