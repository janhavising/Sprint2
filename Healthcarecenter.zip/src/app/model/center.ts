export class Appointment
{

    
    centerId:string;
    testId : string;
    centerName:string;
    address:string;
    contact :number;
    
}