export class Appointment
{

    appointmentId:number;
    userId:string;
    testId : string;
    centerId:string;
    status:string;
    dateTime :string;
    
}