import { Component, OnInit,ViewChild, ElementRef } from '@angular/core';
import { ViewService } from './view.service';
import { Test } from '../model/Test';
import { Router } from '@angular/router';

import * as jsPDF from 'jspdf';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {


  appt:any[];
  dataString :any;
  userId:'u101';
  errorMsg:String;
  constructor(private router: Router , private service : ViewService) { }
  ngOnInit(): void {
  }
  onSubmit(userId1:string)
  {
  
    userId1= "u101";
   
    this.service.getDetails(userId1).subscribe(data=> {this.appt = data;
   // alert(this.appt[0][0]);
    console.log(this.appt);
    },
    (error) => 
    {
      this.errorMsg = error.message;
      alert ("Error is : " + this.errorMsg);
    }
    );
  
    
  }
  @ViewChild('content') content : ElementRef ;

  public downloadMe(){
   
    const doc = new jsPDF();
    
    let specialElementHandlers = {
      '#editor' : function(element, renderer){
        return true; 
      }
    };
    
    let content =this.content.nativeElement; 

    doc.fromHTML(content.innerHTML,15,15,{'width':290,
    'elementHandlers': specialElementHandlers});

    doc.save("Appointment.pdf");
  }

}
