import { Injectable } from '@angular/core';
import { Appointment } from '../model/appointment';
import { Test } from '../model/Test';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ViewService {

 
  constructor(private http:HttpClient) { }

  private baseURL='http://localhost:8885/getAppointment/u101';
  private testURL='http://localhost:8885/AllData';
  private dataURL='http://localhost:8885/getAppointmentDetails'
  public getTest()
  {
    return this.http.get<Test[]>(this.testURL);
  }
  public getDetails(userId:string):Observable<any>
  {
    
    return this.http.get(this.dataURL+"/"+userId);
  }
  
}
