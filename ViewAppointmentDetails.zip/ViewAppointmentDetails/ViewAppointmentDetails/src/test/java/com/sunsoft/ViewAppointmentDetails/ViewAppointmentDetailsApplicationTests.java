package com.sunsoft.ViewAppointmentDetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViewAppointmentDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
