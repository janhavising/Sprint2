package com.sunsoft.ViewAppointmentDetails.controller;




import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunsoft.ViewAppointmentDetails.entity.Appointment;
import com.sunsoft.ViewAppointmentDetails.entity.DiagnosticCenter;
import com.sunsoft.ViewAppointmentDetails.entity.Test;
import com.sunsoft.ViewAppointmentDetails.entity.User;
import com.sunsoft.ViewAppointmentDetails.service.IViewAppointmentDetails;

@RestController
@RequestMapping ("/appointment")
 
public class ViewAppointmentController {

	@Autowired
	IViewAppointmentDetails app_details;
	
	
	@RequestMapping("/getAppointment")
	public Appointment getAppointment (@RequestParam ("userID") String userID)
	{
		
		return app_details.getAppointment(userID);
		
	}
 
    @RequestMapping("/getDiagnosticCenter")
    public String getCenter(@RequestParam("centerId") String centerId)
    {
    	DiagnosticCenter dc=app_details.getCenterName(centerId);
    	return "center Name:  "+dc.getCenterName()+"  "+"Center Address: "+dc.getAddress()+" "+"Contact No: "+dc.getContactNo();
    }
    
    @RequestMapping("/getTestName")
    public String getTest(@RequestParam("testId") String testId)
    {
    	Test test=app_details.getTestName(testId);
    	return test.getTestName();
    }
    @RequestMapping("/getUser")
    public String getUserDetails(@RequestParam("userId") String userId)
    {
    	User user=app_details.getUser(userId);
    	return "User Name is: "+user.getUserName()+" "+"Email Id: "+user.getEmailId()+" "+"Contact No.: "+user.getContactNo();
    }

	@SuppressWarnings("unchecked")
	@RequestMapping("/getAppointmentDetails/{userId}")
    public List<Appointment> getAppointmentDetails (@PathVariable String userID)
	{
		return app_details.viewAppointmentDetails(userID);
		
	}
    
} 
    
