package com.sunsoft.ViewApplicationDetails.exception;

public class ViewApplicationDetailException {

}
