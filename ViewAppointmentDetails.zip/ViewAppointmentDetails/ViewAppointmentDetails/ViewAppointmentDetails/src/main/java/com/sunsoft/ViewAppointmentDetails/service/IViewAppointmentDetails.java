 package com.sunsoft.ViewAppointmentDetails.service;



import java.util.List;

import com.sunsoft.ViewAppointmentDetails.entity.Appointment;
import com.sunsoft.ViewAppointmentDetails.entity.DiagnosticCenter;
import com.sunsoft.ViewAppointmentDetails.entity.Test;
import com.sunsoft.ViewAppointmentDetails.entity.User;

public interface IViewAppointmentDetails {
	
	public Appointment getAppointment (String UserID);

	public DiagnosticCenter getCenterName(String centerId);

	public Test getTestName(String testId);
	@SuppressWarnings("rawtypes")
	public List viewAppointmentDetails(String UserId);

	public User getUser(String userId);
} 
